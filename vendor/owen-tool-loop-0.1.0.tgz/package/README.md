# @owen/tool-loop

A tool-calling loop for TypeScript apps. You write the tools; it runs the
rounds against any model — a Crucible server, a local OpenAI-compatible server
(Ollama, llama.cpp, vLLM, LM Studio), or Anthropic's API — and hands you the
model's summary.

It is the loop from Foundry's Ask, taken out of Foundry: the same round budget,
the same window fitting (cut in chunks, so prompt caches keep hitting), the same
retry rule (weather is retried, misconfiguration is named), the same thinking
echo for Claude, the same working note for follow-ups. Foundry's Ask runs on it.

```
npm install ./vendor/owen-tool-loop-0.1.0.tgz
```

Node 20+. No runtime dependencies. The Anthropic adapter needs
`@anthropic-ai/sdk` installed in the app; the Crucible adapter takes the app's
own `@crucible/client` client.

## Quick start: a local model through Ollama

```ts
import { defineTool, openaiCompatible, runLoop, ToolRegistry } from '@owen/tool-loop';

const markers: { at: number; label: string }[] = [];
const tools = new ToolRegistry([
  defineTool({
    name: 'add_marker',
    description: 'Add a marker to the timeline at a time in seconds.',
    parameters: { type: 'object', properties: { at: { type: 'number' }, label: { type: 'string' } }, required: ['at', 'label'] },
    run: ({ at, label }) => {
      markers.push({ at: Number(at), label: String(label) });
      return { content: `Marker "${label}" at ${at}s.`, said: `marker at ${at}s` };
    },
  }),
]);

const done = await runLoop({
  transport: openaiCompatible({ baseUrl: 'http://localhost:11434/v1', model: 'qwen3:8b', window: 32_768 }),
  tools,
  system: 'You help a person edit a video. Use the tools; when you are done, say what you did.',
  opening: 'Put a marker at every scene change in the transcript below. …',
  signal: new AbortController().signal,
  onProgress: (p) => console.log(p.status),
});
console.log(done.text, markers);
```

## Quick start: Crucible

The app already has a `CrucibleClient` (from its own server registry). Open the
model — a local one is loaded and held by a session for the whole run — then run:

```ts
import { crucibleTransport, openCrucibleTarget, runLoop } from '@owen/tool-loop';

const target = await openCrucibleTarget({
  client,                 // the app's CrucibleClient
  server: 'owens-pc',     // its name, for sentences
  chosen: '',             // a model id, 'anthropic/claude-sonnet-5-5', or '' for Automatic
  act: 'markers',         // what the server shows the work as: one lowercase word
  ceilingB: 27,           // Automatic's ceiling, billions of parameters
  say: (s) => console.log(s),
  signal,
});
const transport = crucibleTransport(target, { act: 'markers' });
try {
  const done = await runLoop({ transport, tools, system, opening, signal });
} finally {
  await transport.release?.();   // gives the card back
}
```

An `anthropic/…` model is forwarded by the server on its own account and holds
nothing. A local model gets `thinking: false`; a forwarded Claude is sent no
switch and its thinking rides back between rounds.

## The pieces

| | |
|---|---|
| `defineTool`, `ToolRegistry` | Tools: a name, a description, a JSON schema, `run(args, ctx) → { content, said? }`. Add, replace, remove and remove-by-group while the program runs. A call to a missing tool, arguments that are not a JSON object, and a tool that throws are answered to the model as results (`onError: 'throw'` ends the run instead). Any object with `specs()` and `call(name, json, ctx)` works in place of a registry. |
| `runLoop` | The rounds. Returns `{ text, rounds, hitLimit, history, fit, tools, maxTokens }`. |
| `takeNote`, `continuation` | The working note after a run, and the opening of a follow-up that starts from one. |
| `runTurn`, `ConversationStore` | Long-term chat: one call per turn, the conversation kept between them. |
| `trimPolicy`, `fullPolicy`, `compactPolicy` | How much context each request carries. |
| `chatWithRetry` | One request with the retry rule, for an app's own one-off calls. |
| `openaiCompatible`, `anthropic`, `openCrucibleTarget` + `crucibleTransport` | Adapters. Anything else: write a `Transport`. |

## `runLoop` options

| Option | Default | |
|---|---|---|
| `transport` | — | The model. |
| `tools` | — | A `ToolRegistry` or any `ToolSource`. |
| `system` | — | The system prompt. |
| `opening` | — | The person's turn (or a `continuation(...)`). |
| `signal` | — | Cancel. Stops before the next request, ends a retry wait at once, and is never retried. |
| `maxRounds` | 40 | Rounds of tool calls. At the limit the last results say so, one more request asks for the summary, and any call in it is dropped (`hitLimit: true`). |
| `maxReplyTokens` | 8000 | The reply budget's ceiling; a stated window caps it at a quarter of the window. |
| `state` | none | `() => string`: the work so far, rebuilt every round and sent as the LAST message, never stored. The way to keep a long run honest after old rounds are cut. |
| `context` | `'trim'` | `'trim'`, `'full'`, `'compact'`, or `(size, transport) => ContextPolicy`. |
| `retry` | 4 tries, 5 s doubling | `{ attempts, firstWaitMs, log }`. |
| `before` | none | Earlier turns' messages, sent between the system prompt and the opening, never cut. |
| `onProgress` | none | `{ round, prose, status, said? }` before each request and after each round's calls. |
| `words` | English defaults | `{ waiting, final, round }`: the progress lines, worded by the app. |
| `limitNote`, `lengthNudge` | defaults | What the model is told at the round limit, and after a reply cut off before it called a tool. |
| `hooks` | none | `beforeRequest` (may return a changed request), `afterReply`, `onToolCall`, `onToolResult`, `stopWhen({ round, reply, calls })`. |

A reply cut off at its token limit with no tool call is not an answer: the
model is nudged and the run goes on.

## Context policies

- **trim** (default) — the history grows to 20 rounds, then is cut back to the
  latest 10 in one step: between cuts every request starts with exactly the
  bytes the last one did, so Claude's prompt cache and vLLM's prefix cache keep
  hitting. A cut leaves one note on the person's turn. When the window is too
  small even for that, it cuts further, down to the last round, and a request
  that still does not fit is refused by name. `trimPolicy({ high, low, droppedNote })`.
  Use it when the tools hold the work (and `state` says it).
- **full** — every round, every request. Outgrowing the window fails by name.
  For short runs where nothing may be forgotten.
- **compact** — every round until a request would use 75% of the window; then
  the model summarizes everything but the last 4 rounds (and any earlier
  summary) in one extra request, and the summary takes their place.
  `compactPolicy({ threshold, keep, summaryTokens, ask })`. For long chats.

## Conversations

```ts
import { JsonFileConversationStore, runTurn } from '@owen/tool-loop';

const store = new JsonFileConversationStore(path.join(projectDir, 'chats.json'));
const turn = await runTurn({ store, conversation: null, request: 'What changed in act 2?', transport, tools, system, signal });
// later
await runTurn({ store, conversation: turn.conversation.id, request: 'And act 3?', transport, tools, system, signal });
```

`carry: 'note'` (default) asks the model, after each turn, for a working note to
itself and opens the next turn from it — framed as leads to check, since things
may have changed. Cheap: the rounds are never carried. `carry: 'full'` keeps
every message of every turn and sends them all; pair it with `context: 'compact'`.
A note that cannot be had costs the turn nothing (`noteProblem` says why the
next turn starts fresh). Stores: `MemoryConversationStore`,
`JsonFileConversationStore` (written whole, atomically; a rename refused for a
moment on Windows or a network share is retried), or your own four methods.

## Writing a transport

```ts
const transport: Transport = {
  label: 'my-server', model: 'm', window: 32_768, local: true,
  async chat(request) { /* send request.messages, request.tools … return a ChatReply */ },
  isWeather: (err) => /* true for what a wait can end */ false,
};
```

Messages are Crucible's chat shapes (`role`, `content`, `toolCalls`,
`toolCallId`, `contentBlocks`) — OpenAI's, camel-cased.

## Building and packing

```
npm run build     # dist/esm and dist/cjs, both typed
bun test
npm run pack      # owen-tool-loop-<version>.tgz
```

An app pins the tarball the way Foundry pins `@crucible/client`: copy it into
the app's `vendor/` and `"@owen/tool-loop": "file:vendor/owen-tool-loop-0.1.0.tgz"`.

## Porting to Python

The shapes carry over one for one. `Transport` is a protocol with `label`,
`model`, `window`, `local`, `async chat(request) -> ChatReply`,
`is_weather(err) -> bool` and an optional `release()`. A tool is a dataclass of
name, description, JSON-schema dict and `run(args, ctx) -> ToolResult`; the
registry is a dict. `run_loop` is one async function with the same options
(cancel by `asyncio` task cancellation instead of an `AbortSignal`). Keep the
three numbers — 20/10 for trim, 0.4 tokens a character until measured, 95% of
the window — and the retry rule's 4 tries doubling from 5 s, and the two
implementations will send the same requests.
