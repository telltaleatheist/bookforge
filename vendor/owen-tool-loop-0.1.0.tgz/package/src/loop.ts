import type { ChatReply, ChatRequest, Held, Message, ToolCall, ToolSpec } from './messages.js';
import type { Transport } from './transport.js';
import type { ToolResult, ToolSource } from './tools.js';
import { chatWithRetry, DEFAULT_RETRY, type RetryPolicy } from './retry.js';
import { policyFor, type ContextChoice, type ContextPolicy } from './context.js';

/** Tokens per reply: 8000, or a quarter of a small window. */
export const MAX_REPLY_TOKENS = 8000;

export const DEFAULT_MAX_ROUNDS = 40;

/** Appended to the results of the last round that may call tools. */
export const LIMIT_NOTE = 'No more tool calls can be made. Write your summary for the person now.';

/** Said to a model whose reply hit its token limit before it called a tool. */
export function lengthNudge(maxTokens: number): string {
  return `Your last reply hit the ${maxTokens}-token limit before it called a tool. Keep your reasoning to a few sentences and make the next tool call now.`;
}

/** What progress is told: the round, the model's prose if it said something, and a line for the person. */
export interface Progress<S> {
  readonly round: number;
  readonly prose: string | null;
  readonly status: string;
  /** The round's calls, worded by their tools; present on the line said after a round's calls ran. */
  readonly said?: readonly S[];
}

/** The lines progress says. Every one has a default; an app words its own. */
export interface StatusWords<S> {
  /** Before a request: "Round 3 of 40: waiting for m…". */
  waiting?(round: number, maxRounds: number, model: string): string;
  /** Before the last request, which asks only for the summary. */
  final?(round: number, model: string): string;
  /** After a round's calls ran. */
  round?(round: number, said: readonly S[], reply: ChatReply): string;
}

export interface LoopHooks<S> {
  /** The request about to be sent; return a changed one to send that instead. */
  beforeRequest?(request: ChatRequest, round: number): ChatRequest | void;
  afterReply?(reply: ChatReply, round: number): void;
  onToolCall?(call: ToolCall, round: number): void;
  onToolResult?(call: ToolCall, result: ToolResult<S>, round: number): void;
  /** Checked after each round's calls ran; true ends the run there, as if the model had stopped. */
  stopWhen?(state: { round: number; reply: ChatReply; calls: readonly ToolCall[] }): boolean;
}

export interface LoopOptions<S = string> {
  readonly transport: Transport;
  readonly tools: ToolSource<S>;
  readonly system: string;
  /** The person's turn: their request, or a continuation that carries a note. */
  readonly opening: string;
  readonly signal: AbortSignal;
  /**
   * Turns that came before this one, sent between the system prompt and the
   * opening and never cut (they carry no round). For a conversation that keeps
   * its whole context from turn to turn.
   */
  readonly before?: readonly Message[];
  /** Rounds of tool calls before the model is asked only for its summary. */
  readonly maxRounds?: number;
  /** The reply budget's ceiling; a quarter of a stated window caps it further. */
  readonly maxReplyTokens?: number;
  /** The work so far, rebuilt every round and sent LAST. Null or absent: no state message. */
  readonly state?: () => string | null;
  readonly context?: ContextChoice;
  readonly retry?: RetryPolicy;
  readonly onProgress?: (progress: Progress<S>) => void;
  readonly words?: StatusWords<S>;
  readonly limitNote?: string;
  readonly lengthNudge?: (maxTokens: number) => string;
  readonly hooks?: LoopHooks<S>;
}

/** The loop's end: the summary, and the conversation as it stands, which a note is asked on. */
export interface Finished {
  /** The model's last prose: the summary for the person. */
  readonly text: string;
  readonly rounds: number;
  /** True when the run stopped at the round limit rather than by finishing. */
  readonly hitLimit: boolean;
  readonly history: Held[];
  /** The context policy as the run left it (what has been cut stays cut). */
  readonly fit: ContextPolicy;
  readonly tools: readonly ToolSpec[];
  readonly maxTokens: number;
}

/** The reply budget for a window: the ceiling, or a quarter of a small window. */
export function replyBudget(window: number | null, ceiling: number = MAX_REPLY_TOKENS): number {
  return window === null ? ceiling : Math.min(ceiling, Math.floor(window / 4));
}

/**
 * THE ROUNDS. Ends when the model stops calling tools (its last prose is the
 * summary), or at the round limit, where one last request asks only for the
 * summary and any tool call in its answer is dropped. A reply cut off at its
 * token limit with no call is not an answer — it ran out mid-thought — so it is
 * nudged and the run goes on.
 */
export async function runLoop<S = string>(options: LoopOptions<S>): Promise<Finished> {
  const { transport, signal } = options;
  const maxRounds = options.maxRounds ?? DEFAULT_MAX_ROUNDS;
  const retry = options.retry ?? DEFAULT_RETRY;
  const words = options.words ?? {};
  const progress = options.onProgress ?? ((): void => {});
  const hooks = options.hooks ?? {};
  const tools = options.tools.specs();
  const maxTokens = replyBudget(transport.window, options.maxReplyTokens);
  const fit = policyFor(options.context ?? 'trim', { window: transport.window, maxTokens, toolChars: JSON.stringify(tools).length }, transport, retry);
  const history: Held[] = [
    { message: { role: 'system', content: options.system } },
    ...(options.before ?? []).map((message) => ({ message })),
    { message: { role: 'user', content: options.opening } },
  ];
  let summary = '';
  const done = (rounds: number, hitLimit: boolean): Finished => ({ text: summary, rounds, hitLimit, history, fit, tools, maxTokens });

  for (let round = 0; ; round += 1) {
    signal.throwIfAborted();
    const final = round >= maxRounds;
    progress({
      round,
      prose: null,
      status: final
        ? (words.final?.(round, transport.model) ?? `Round ${round}: asking ${transport.model} for its summary…`)
        : (words.waiting?.(round, maxRounds, transport.model) ?? `Round ${round + 1} of ${maxRounds}: waiting for ${transport.model}…`),
    });
    const { wired, chars } = await fit.wire(history, round, options.state?.() ?? null, signal);
    let request: ChatRequest = {
      model: transport.model,
      messages: wired,
      maxTokens,
      tools,
      /*
       * 'auto' EVEN ON THE LAST ROUND. A server may refuse a tool_choice a model
       * does not take, and a refusal there would throw away the run for a
       * summary. The last results already say no more calls can be made, and any
       * call made anyway is dropped below.
       */
      toolChoice: 'auto',
      signal,
    };
    request = hooks.beforeRequest?.(request, round) ?? request;
    const reply = await chatWithRetry(transport, request, retry);
    hooks.afterReply?.(reply, round);
    if (reply.usage?.promptTokens) fit.measured(reply.usage.promptTokens, chars);
    const calls: readonly ToolCall[] = final ? [] : reply.toolCalls;
    /*
     * A THINKING CLAUDE'S TURN GOES BACK AS IT CAME. A tool loop keeps that
     * thinking only if each turn's blocks are sent back verbatim beside the same
     * content and calls. So they ride only when the calls are the reply's own;
     * the last round drops its calls and is never sent again anyway.
     */
    const blocks = !final && reply.contentBlocks.length > 0 ? { contentBlocks: reply.contentBlocks } : {};
    history.push({
      message: {
        role: 'assistant',
        content: reply.content,
        ...(calls.length > 0 ? { toolCalls: calls } : {}),
        ...blocks,
      },
      round,
    });
    if (reply.content !== null && reply.content.trim().length > 0) summary = reply.content.trim();

    // The calls run before the round is said, so its line can say what each one did.
    const said: S[] = [];
    for (const call of calls) {
      hooks.onToolCall?.(call, round);
      const result = await options.tools.call(call.function.name, call.function.arguments, { signal, round, callId: call.id });
      hooks.onToolResult?.(call, result, round);
      if (result.said !== undefined) said.push(result.said);
      let content = result.content;
      if (round + 1 >= maxRounds) content += `\n\n${options.limitNote ?? LIMIT_NOTE}`;
      history.push({ message: { role: 'tool', toolCallId: call.id, content }, round });
    }
    progress({
      round,
      prose: reply.content,
      status: words.round?.(round, said, reply)
        ?? `Round ${round + 1}: ${calls.length === 0 ? 'no tool calls' : calls.map((c) => c.function.name).join(', ')}`,
      said,
    });

    if (calls.length > 0 && hooks.stopWhen?.({ round, reply, calls })) return done(round + 1, false);
    if (calls.length === 0) {
      if (final) return done(round + 1, true);
      if (reply.finishReason === 'length') {
        history.push({ message: { role: 'user', content: (options.lengthNudge ?? lengthNudge)(maxTokens) }, round });
        continue;
      }
      return done(round + 1, false);
    }
  }
}
