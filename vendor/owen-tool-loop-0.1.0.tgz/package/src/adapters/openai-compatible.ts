import type { ChatReply, Message, ToolCall } from '../messages.js';
import type { Transport } from '../transport.js';

/**
 * ANY OPENAI-COMPATIBLE SERVER — Ollama, llama.cpp's server, vLLM, LM Studio,
 * or a hosted API that speaks `POST /v1/chat/completions` with tools. Plain
 * `fetch`; no SDK.
 */
export interface OpenAICompatibleOptions {
  /** Up to and including `/v1`: `http://localhost:11434/v1` for Ollama. */
  readonly baseUrl: string;
  readonly model: string;
  readonly apiKey?: string;
  /** Who answers, for sentences. Default: the URL's host. */
  readonly label?: string;
  /** The context window in tokens, when known. Null: only chunking applies. See {@link probeWindow}. */
  readonly window?: number | null;
  /** True for a model on this machine or the person's own card. Default true. */
  readonly local?: boolean;
  /** More fields for every request body (`temperature`, `top_p`, a server's own switches). */
  readonly body?: Readonly<Record<string, unknown>>;
  readonly headers?: Readonly<Record<string, string>>;
  /** For tests, or a fetch with its own agent. */
  readonly fetch?: typeof fetch;
}

/** A server that answered, and refused. */
export class HttpRefusal extends Error {
  constructor(readonly status: number, readonly body: string, label: string) {
    super(`${label} answered ${status}: ${body.length > 500 ? `${body.slice(0, 500)}…` : body}`);
    this.name = 'HttpRefusal';
  }
}

/** A server that could not be reached at all. */
export class Unreachable extends Error {
  constructor(readonly url: string, cause: unknown) {
    super(`${url} could not be reached: ${cause instanceof Error ? cause.message : String(cause)}`);
    this.name = 'Unreachable';
  }
}

/** Weather: unreachable, a 5xx, a 429, a 408. */
export function httpWeather(err: unknown): boolean {
  if (err instanceof Unreachable) return true;
  if (err instanceof HttpRefusal) return err.status >= 500 || err.status === 429 || err.status === 408;
  return false;
}

/** Our messages → OpenAI's: `toolCalls` → `tool_calls`, `toolCallId` → `tool_call_id`. Blocks are Claude's and are not sent. */
export function toOpenAI(messages: readonly Message[]): Record<string, unknown>[] {
  return messages.map((m) => {
    if (m.role === 'assistant') {
      return {
        role: 'assistant',
        content: m.content,
        ...(m.toolCalls !== undefined && m.toolCalls.length > 0 ? { tool_calls: m.toolCalls } : {}),
      };
    }
    if (m.role === 'tool') return { role: 'tool', tool_call_id: m.toolCallId, content: m.content };
    return { role: m.role, content: m.content };
  });
}

interface OpenAIChoice {
  message?: { content?: string | null; tool_calls?: { id?: string; type?: string; function?: { name?: string; arguments?: unknown } }[] };
  finish_reason?: string | null;
}

/** OpenAI's answer → ours. A call with no id gets one, since its tool message must name it. */
export function fromOpenAI(body: unknown, label: string): ChatReply {
  const b = body as { choices?: OpenAIChoice[]; usage?: { prompt_tokens?: number } };
  const choice = b.choices?.[0];
  if (choice === undefined || choice.message === undefined) {
    throw new Error(`${label} answered with no choice, so there is no reply to read.`);
  }
  const calls: ToolCall[] = (choice.message.tool_calls ?? []).map((c, i) => ({
    id: c.id ?? `call_${i}`,
    type: 'function',
    function: {
      name: c.function?.name ?? '',
      // Ollama has answered with an object here; the loop takes the JSON text.
      arguments: typeof c.function?.arguments === 'string' ? c.function.arguments : JSON.stringify(c.function?.arguments ?? {}),
    },
  }));
  return {
    content: choice.message.content ?? null,
    toolCalls: calls,
    contentBlocks: [],
    finishReason: choice.finish_reason ?? null,
    usage: b.usage?.prompt_tokens === undefined ? null : { promptTokens: b.usage.prompt_tokens },
  };
}

export function openaiCompatible(options: OpenAICompatibleOptions): Transport {
  const base = options.baseUrl.replace(/\/+$/, '');
  const label = options.label ?? new URL(base).host;
  const doFetch = options.fetch ?? fetch;
  return {
    label,
    model: options.model,
    window: options.window ?? null,
    local: options.local ?? true,
    async chat(request) {
      const url = `${base}/chat/completions`;
      let response: Response;
      try {
        response = await doFetch(url, {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            ...(options.apiKey === undefined ? {} : { authorization: `Bearer ${options.apiKey}` }),
            ...options.headers,
          },
          body: JSON.stringify({
            ...options.body,
            model: request.model,
            messages: toOpenAI(request.messages),
            max_tokens: request.maxTokens,
            ...(request.tools.length > 0 ? { tools: request.tools, tool_choice: request.toolChoice } : {}),
          }),
          signal: request.signal,
        });
      } catch (err) {
        if (request.signal.aborted) throw err;
        throw new Unreachable(url, err);
      }
      const text = await response.text();
      if (!response.ok) throw new HttpRefusal(response.status, text, label);
      let body: unknown;
      try {
        body = JSON.parse(text);
      } catch {
        throw new Error(`${label} answered something that is not JSON: ${text.slice(0, 200)}`);
      }
      return fromOpenAI(body, label);
    },
    isWeather: httpWeather,
  };
}

/**
 * THE WINDOW, ASKED: vLLM lists `max_model_len` on `GET /v1/models`, Ollama
 * states `num_ctx`-independent `context_length` on `POST /api/show`. Null when
 * neither says, which leaves the run to chunking.
 */
export async function probeWindow(baseUrl: string, model: string, doFetch: typeof fetch = fetch): Promise<number | null> {
  const base = baseUrl.replace(/\/+$/, '');
  try {
    const listed = await doFetch(`${base}/models`);
    if (listed.ok) {
      const body = await listed.json() as { data?: { id?: string; max_model_len?: number }[] };
      const found = body.data?.find((m) => m.id === model)?.max_model_len;
      if (typeof found === 'number') return found;
    }
  } catch { /* not vLLM's listing; try Ollama's below */ }
  try {
    const root = base.replace(/\/v1$/, '');
    const shown = await doFetch(`${root}/api/show`, { method: 'POST', body: JSON.stringify({ model }) });
    if (shown.ok) {
      const body = await shown.json() as { model_info?: Record<string, unknown> };
      for (const [key, value] of Object.entries(body.model_info ?? {})) {
        if (key.endsWith('.context_length') && typeof value === 'number') return value;
      }
    }
  } catch { /* neither said */ }
  return null;
}
