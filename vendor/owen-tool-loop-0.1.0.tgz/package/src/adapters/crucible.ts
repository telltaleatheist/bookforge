import type { ChatReply, Message, ToolSpec, ToolChoice } from '../messages.js';
import type { Transport } from '../transport.js';

/**
 * CRUCIBLE — a Crucible server, through `@crucible/client`. The module does not
 * import the SDK: an app passes its own client (it already has one, made from
 * its own server registry), and the adapter speaks to it by shape.
 *
 * Two steps, as Foundry's Ask takes them:
 *
 *   1. {@link openCrucibleTarget}: make the chosen model ready. A LOCAL model is
 *      loaded and HELD for the whole run by a queue session — forty rounds are
 *      forty chats, and without the hold another client's load could evict the
 *      model between any two. AUTOMATIC (an empty choice) opens the session at
 *      a ceiling in billions of parameters and lets the server name the model.
 *      A CLOUD model (`anthropic/…`, any id with a `/`) is forwarded by the
 *      server on its own account and holds nothing.
 *   2. {@link crucibleTransport}: the ready target as a {@link Transport}.
 */

/** The parts of a `CrucibleClient` the adapter uses. */
export interface CrucibleClientLike {
  chat(options: {
    model: string;
    messages: readonly Message[];
    maxTokens: number;
    tools: readonly ToolSpec[];
    toolChoice: ToolChoice;
    act: string;
    signal: AbortSignal;
    thinking?: boolean;
  }): Promise<ChatReply>;
  models(): Promise<readonly { id: string; maxModelLen: number | null; contextDefault: number }[]>;
  session?(options: CrucibleSessionOptionsLike): Promise<CrucibleSessionLike>;
}

/** What the default holder asks a session with: `@crucible/client`'s `SessionOptions`, the parts it sends. */
export interface CrucibleSessionOptionsLike {
  readonly act: string;
  readonly model?: string;
  readonly maxParamsB?: number;
  readonly idleS?: number;
  readonly maxWaitS?: number;
  readonly onQueue?: (position: { position: number; of: number }) => void;
  readonly onWaiting?: (waiting: { message: string }) => void;
  readonly signal?: AbortSignal;
}

/** The parts of a `CrucibleSession` the default holder uses. */
export interface CrucibleSessionLike {
  readonly id: string;
  readonly model: string | null;
  readonly closed: Promise<{ reason: string; message: string }>;
  touch(): Promise<unknown>;
  close(): Promise<unknown>;
}

/** A held turn on a card. `release` is idempotent and never throws. */
export interface HeldSession {
  readonly id: string;
  readonly model: string | null;
  release(): Promise<void>;
}

/** Which model a session opens with: one named, or the server's own pick under a ceiling. */
export type SessionPick = { readonly model: string } | { readonly maxParamsB: number };

/** A model made ready: Foundry's `Target`, field for field. */
export interface CrucibleTarget<C extends CrucibleClientLike = CrucibleClientLike> {
  readonly server: string;
  readonly client: C;
  readonly model: string;
  readonly local: boolean;
  readonly window: number | null;
  readonly session: HeldSession | null;
}

/**
 * CLAUDE'S WINDOW. Crucible's upstream listing states no window for a forwarded
 * model, and every Claude model an anthropic account serves takes 200k; a model
 * that takes less answers with a 400 naming its own limit.
 */
export const CLAUDE_WINDOW = 200_000;

/** The window of a forwarded model, from its id: Claude's, or not stated. */
export function upstreamWindow(model: string): number | null {
  return model.startsWith('anthropic/') ? CLAUDE_WINDOW : null;
}

/** The session's idle window, a touch every fifth of it, and the longest wait in the server's line. */
const SESSION_IDLE_S = 300;
const SESSION_TOUCH_MS = 60_000;
const SESSION_MAX_WAIT_S = 86_400;

/**
 * HOLD A TURN ON THE CARD — wait in the server's line, then keep the session
 * present with a touch every minute, for as long as this process holds it. A
 * process that dies stops touching and the card is handed on when the session
 * idles out. Release is idempotent and swallows its own failure after logging:
 * a session that cannot be closed idles out, and failing finished work over
 * the tidying would report a loss that did not happen.
 */
export async function holdSession(
  client: CrucibleClientLike,
  pick: SessionPick,
  act: string,
  label: string,
  say: (line: string) => void,
  signal?: AbortSignal,
  log: (line: string) => void = (line) => console.error(`[tool-loop] ${line}`),
): Promise<HeldSession> {
  if (client.session === undefined) {
    throw new Error(`The client for ${label} cannot open a session, so a local model cannot be held for the run.`);
  }
  const session = await client.session({
    act,
    ...pick,
    idleS: SESSION_IDLE_S,
    maxWaitS: SESSION_MAX_WAIT_S,
    onQueue: ({ position, of }: { position: number; of: number }) => {
      say(`Waiting for ${label}: #${position}${of < position ? '' : ` of ${of}`} in its line`);
    },
    onWaiting: ({ message }: { message: string }) => {
      say(`Waiting for ${label}: ${message}`);
    },
    ...(signal === undefined ? {} : { signal }),
  });
  let ended = false;
  let touching = false;
  const timer = setInterval(() => {
    if (ended || touching) return;
    touching = true;
    session.touch()
      .catch((err: unknown) => {
        log(`a touch of session ${session.id} on ${label} failed: ${err instanceof Error ? err.message : String(err)}`);
      })
      .finally(() => { touching = false; });
  }, SESSION_TOUCH_MS);
  (timer as { unref?: () => void }).unref?.();
  void session.closed.then((end) => {
    if (ended) return;
    ended = true;
    clearInterval(timer);
    if (end.reason !== 'client') log(`${label} ended session ${session.id} (${end.reason}): ${end.message}`);
  });
  return {
    id: session.id,
    model: session.model,
    async release(): Promise<void> {
      if (ended) return;
      ended = true;
      clearInterval(timer);
      try {
        await session.close();
      } catch (err) {
        log(`the session on ${session.model ?? act} at ${label} could not be closed (it idles out in ${SESSION_IDLE_S}s): `
          + `${err instanceof Error ? err.message : String(err)}`);
      }
    },
  };
}

export interface OpenCrucibleOptions<C extends CrucibleClientLike = CrucibleClientLike> {
  readonly client: C;
  /** The server's name, for sentences. */
  readonly server: string;
  /** A model id, an upstream id (`anthropic/…`), or '' for Automatic. */
  readonly chosen: string;
  /** What the server shows the work as: one lowercase word. */
  readonly act: string;
  /** Automatic's ceiling, in billions of parameters. */
  readonly ceilingB: number;
  readonly say: (status: string) => void;
  readonly signal: AbortSignal;
  /** A forwarded model's window. Default {@link upstreamWindow}. */
  readonly upstreamWindowOf?: (model: string) => number | null;
  /**
   * How a local model's session is held. Default {@link holdSession}; an app
   * that already owns its sessions (Foundry's placements do) passes its own, so
   * one thing in it holds every turn on a card.
   */
  readonly openSession?: (pick: SessionPick, say: (line: string) => void, signal: AbortSignal) => Promise<HeldSession>;
}

/** THE MODEL A CHOICE NAMED, made ready: a local model loaded and held, a forwarded one passed through. */
export async function openCrucibleTarget<C extends CrucibleClientLike>(options: OpenCrucibleOptions<C>): Promise<CrucibleTarget<C>> {
  const { client, server, chosen, say, signal } = options;
  if (chosen.includes('/')) {
    // Forwarded on the server's upstream account: nothing on the card to hold.
    return {
      server,
      client,
      model: chosen,
      local: false,
      window: (options.upstreamWindowOf ?? upstreamWindow)(chosen),
      session: null,
    };
  }
  say(chosen.length === 0
    ? `Asking ${server} for its turn and its own model (up to ${options.ceilingB}B)…`
    : `Asking ${server} for its turn and loading ${chosen}…`);
  const pick: SessionPick = chosen.length === 0 ? { maxParamsB: options.ceilingB } : { model: chosen };
  const session = options.openSession !== undefined
    ? await options.openSession(pick, say, signal)
    : await holdSession(client, pick, options.act, server, say, signal);
  try {
    const model = chosen.length > 0 ? chosen : session.model;
    if (model === null) {
      throw new Error(`${server} opened its turn for Automatic and did not say which model it chose.`);
    }
    const info = (await client.models()).find((m) => m.id === model);
    if (info === undefined) {
      throw new Error(`${server} opened its turn with ${model} and then did not list it, so its window is not known.`);
    }
    return {
      server,
      client,
      model,
      local: true,
      // The window in force; while a model is not resident the server states
      // only the window it would load it at, which is the same number by intent.
      window: info.maxModelLen ?? info.contextDefault,
      session,
    };
  } catch (err) {
    await session.release();
    throw err;
  }
}

/**
 * Weather from `@crucible/client`'s errors, read by their names and statuses so
 * the module needs no SDK: unreachable, any server error, 429 and 408. An app
 * that has the SDK passes its own `instanceof` rule instead.
 */
export function crucibleWeather(err: unknown): boolean {
  if (typeof err !== 'object' || err === null) return false;
  const e = err as { name?: unknown; status?: unknown };
  if (e.name === 'CrucibleUnreachable') return true;
  if (typeof e.status !== 'number' || typeof e.name !== 'string' || !e.name.startsWith('Crucible')) return false;
  return e.status >= 500 || e.status === 429 || e.status === 408;
}

export interface CrucibleTransportOptions {
  readonly act: string;
  /**
   * Thinking on a local model is the chat template's switch. Default: off on a
   * local model (`thinking: false` is sent), and nothing sent for a forwarded
   * one — a newer Claude thinks by default and its blocks ride back.
   */
  readonly thinking?: 'off-when-local' | 'never-sent';
  readonly isWeather?: (err: unknown) => boolean;
}

/** A ready target as a {@link Transport}. `release` gives back its session. */
export function crucibleTransport(target: CrucibleTarget, options: CrucibleTransportOptions): Transport {
  const offWhenLocal = (options.thinking ?? 'off-when-local') === 'off-when-local';
  return {
    label: target.server,
    model: target.model,
    window: target.window,
    local: target.local,
    async chat(request) {
      return target.client.chat({
        model: request.model,
        messages: request.messages,
        maxTokens: request.maxTokens,
        tools: request.tools,
        toolChoice: request.toolChoice,
        act: options.act,
        signal: request.signal,
        ...(target.local && offWhenLocal ? { thinking: false } : {}),
      });
    },
    isWeather: options.isWeather ?? crucibleWeather,
    async release() {
      await target.session?.release();
    },
  };
}
