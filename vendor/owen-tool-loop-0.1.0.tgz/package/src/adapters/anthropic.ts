import type { ChatReply, ContentBlock, Message, ToolCall, ToolChoice, ToolSpec } from '../messages.js';
import type { Transport } from '../transport.js';

/**
 * ANTHROPIC'S API, DIRECT — through the official SDK (`@anthropic-ai/sdk`, an
 * optional peer: install it in the app that uses this adapter). Pass a client
 * you made, or an `apiKey` and the adapter makes one.
 *
 * A THINKING CLAUDE keeps its thinking across a tool loop only when each of its
 * turns goes back exactly as it came. A reply that thought is answered with its
 * blocks in `contentBlocks`; the loop puts them on the assistant message; this
 * adapter sends them back as that turn's content, verbatim.
 */

/** The part of an `Anthropic` client the adapter uses. */
export interface AnthropicLike {
  messages: {
    create(params: Record<string, unknown>, options?: { signal?: AbortSignal }): Promise<unknown>;
  };
}

export interface AnthropicOptions {
  /** An `@anthropic-ai/sdk` model id: `claude-sonnet-5-5`, `claude-opus-5-5`, … */
  readonly model: string;
  readonly client?: AnthropicLike;
  /** Used only when no client is given. Default: the SDK's own (`ANTHROPIC_API_KEY`). */
  readonly apiKey?: string;
  /** Default 200,000. */
  readonly window?: number;
  /** More fields for every request: `thinking`, `temperature`, `metadata`, … */
  readonly params?: Readonly<Record<string, unknown>>;
  readonly label?: string;
}

type Block = Record<string, unknown> & { type: string };
interface Turn { role: 'user' | 'assistant'; content: Block[] }

function argsOf(call: ToolCall): unknown {
  try {
    return JSON.parse(call.function.arguments);
  } catch {
    // What the model wrote; the tool already answered that it was not JSON.
    return {};
  }
}

/** Our messages → the Messages API: one system string, and strictly alternating turns. */
export function toAnthropic(messages: readonly Message[]): { system: string | undefined; turns: Turn[] } {
  const system: string[] = [];
  const turns: Turn[] = [];
  const push = (role: Turn['role'], blocks: Block[]): void => {
    const last = turns.at(-1);
    if (last !== undefined && last.role === role) {
      // Tool results first: Claude reads them as answers to the turn before.
      last.content = role === 'user'
        ? [...last.content.filter((b) => b.type === 'tool_result'), ...blocks.filter((b) => b.type === 'tool_result'),
          ...last.content.filter((b) => b.type !== 'tool_result'), ...blocks.filter((b) => b.type !== 'tool_result')]
        : [...last.content, ...blocks];
    } else {
      turns.push({ role, content: blocks });
    }
  };
  for (const m of messages) {
    if (m.role === 'system') { system.push(m.content); continue; }
    if (m.role === 'user') { push('user', [{ type: 'text', text: m.content }]); continue; }
    if (m.role === 'tool') { push('user', [{ type: 'tool_result', tool_use_id: m.toolCallId, content: m.content }]); continue; }
    if (m.role !== 'assistant') continue;
    if (m.contentBlocks !== undefined && m.contentBlocks.length > 0) {
      push('assistant', m.contentBlocks.map((b) => ({ ...b })));
      continue;
    }
    const blocks: Block[] = [];
    if (m.content !== null && m.content.length > 0) blocks.push({ type: 'text', text: m.content });
    for (const call of m.toolCalls ?? []) {
      blocks.push({ type: 'tool_use', id: call.id, name: call.function.name, input: argsOf(call) });
    }
    push('assistant', blocks.length > 0 ? blocks : [{ type: 'text', text: '' }]);
  }
  return { system: system.length > 0 ? system.join('\n\n') : undefined, turns };
}

function toolChoiceOf(choice: ToolChoice): Record<string, unknown> {
  if (choice === 'auto') return { type: 'auto' };
  if (choice === 'none') return { type: 'none' };
  if (choice === 'required') return { type: 'any' };
  return { type: 'tool', name: choice.function.name };
}

const STOP: Record<string, string> = { end_turn: 'stop', stop_sequence: 'stop', max_tokens: 'length', tool_use: 'tool_calls' };

/** The Messages API's answer → ours. */
export function fromAnthropic(body: unknown): ChatReply {
  const b = body as {
    content?: Block[];
    stop_reason?: string | null;
    usage?: { input_tokens?: number; cache_read_input_tokens?: number | null; cache_creation_input_tokens?: number | null };
  };
  const blocks = b.content ?? [];
  const text = blocks.filter((x) => x.type === 'text').map((x) => String(x['text'] ?? '')).join('');
  const calls: ToolCall[] = blocks.filter((x) => x.type === 'tool_use').map((x) => ({
    id: String(x['id']),
    type: 'function',
    function: { name: String(x['name']), arguments: JSON.stringify(x['input'] ?? {}) },
  }));
  const thought = blocks.some((x) => x.type === 'thinking' || x.type === 'redacted_thinking');
  const u = b.usage;
  return {
    content: text.length > 0 ? text : (calls.length > 0 ? null : ''),
    toolCalls: calls,
    contentBlocks: thought ? (blocks as ContentBlock[]) : [],
    finishReason: b.stop_reason === undefined || b.stop_reason === null ? null : (STOP[b.stop_reason] ?? b.stop_reason),
    usage: u?.input_tokens === undefined ? null
      : { promptTokens: u.input_tokens + (u.cache_read_input_tokens ?? 0) + (u.cache_creation_input_tokens ?? 0) },
  };
}

/** Weather: no connection, a 5xx, 529 (overloaded), 429, 408. */
export function anthropicWeather(err: unknown): boolean {
  if (typeof err !== 'object' || err === null) return false;
  const e = err as { name?: unknown; status?: unknown };
  if (e.name === 'APIConnectionError' || e.name === 'APIConnectionTimeoutError') return true;
  return typeof e.status === 'number' && (e.status >= 500 || e.status === 429 || e.status === 408);
}

export function anthropic(options: AnthropicOptions): Transport {
  let client: AnthropicLike | undefined = options.client;
  const clientOf = async (): Promise<AnthropicLike> => {
    if (client !== undefined) return client;
    let sdk: { default: new (o: Record<string, unknown>) => AnthropicLike };
    try {
      sdk = await import('@anthropic-ai/sdk') as unknown as typeof sdk;
    } catch {
      throw new Error('The anthropic adapter needs @anthropic-ai/sdk installed in the app (npm install @anthropic-ai/sdk), or a client passed as `client`.');
    }
    client = new sdk.default(options.apiKey === undefined ? {} : { apiKey: options.apiKey });
    return client;
  };
  return {
    label: options.label ?? 'anthropic',
    model: options.model,
    window: options.window ?? 200_000,
    local: false,
    async chat(request) {
      const { system, turns } = toAnthropic(request.messages);
      const tools = request.tools.map((t: ToolSpec) => ({
        name: t.function.name,
        description: t.function.description,
        input_schema: t.function.parameters,
      }));
      const body = await (await clientOf()).messages.create({
        ...options.params,
        model: request.model,
        max_tokens: request.maxTokens,
        messages: turns,
        ...(system === undefined ? {} : { system }),
        ...(tools.length > 0 ? { tools, tool_choice: toolChoiceOf(request.toolChoice) } : {}),
      }, { signal: request.signal });
      return fromAnthropic(body);
    },
    isWeather: anthropicWeather,
  };
}
