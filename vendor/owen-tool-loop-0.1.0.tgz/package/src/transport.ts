import type { ChatReply, ChatRequest } from './messages.js';

/**
 * THE MODEL SIDE — one model, ready to answer. An adapter makes one of these
 * (adapters/crucible.ts, adapters/openai-compatible.ts, adapters/anthropic.ts),
 * and an app with its own server writes its own: four fields and two functions.
 */
export interface Transport {
  /** Who answers, for sentences: a server's name, `ollama`, `anthropic`. */
  readonly label: string;
  /** The model id every request names. */
  readonly model: string;
  /**
   * The model's context window in tokens, or null when nothing states it. With
   * null the context policies can only chunk; the server's own refusal names
   * its limit if the conversation outgrows it.
   */
  readonly window: number | null;
  /**
   * True for a model on the person's own card. The loop uses it for one thing:
   * the follow-up note's token cap applies to a local model, while a cloud model
   * that thinks by default is given the run's whole reply budget.
   */
  readonly local: boolean;
  chat(request: ChatRequest): Promise<ChatReply>;
  /**
   * WEATHER, NOT MISCONFIGURATION: true for what a wait can end (unreachable,
   * 5xx, 429, 408). Everything else is the request being wrong and is said in
   * the server's own words, never retried.
   */
  isWeather(err: unknown): boolean;
  /** Give back whatever the transport holds (a session on a card). Idempotent; never throws. */
  release?(): Promise<void>;
}
