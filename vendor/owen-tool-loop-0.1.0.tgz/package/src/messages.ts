/**
 * THE WIRE SHAPES the loop speaks. They are Crucible's chat shapes
 * (`@crucible/client`'s `ChatMessage`, `ChatTool`, `ChatToolCall`), copied
 * field for field rather than imported, so the module has no runtime
 * dependency and a Crucible client's messages pass through untouched. Every
 * other adapter translates to and from these.
 */

/** One call the model made. `arguments` is the JSON text exactly as the model wrote it. */
export interface ToolCall {
  readonly id: string;
  readonly type: 'function';
  readonly function: {
    readonly name: string;
    readonly arguments: string;
  };
}

/**
 * One block of a Claude turn as the Messages API wrote it (`thinking`,
 * `redacted_thinking`, `text`, `tool_use`). Opaque: sent back unchanged so a
 * thinking model keeps its thinking across a tool loop.
 */
export type ContentBlock = Readonly<Record<string, unknown>> & {
  readonly type: 'thinking' | 'redacted_thinking' | 'text' | 'tool_use';
};

export interface TextMessage {
  readonly role: 'system' | 'user';
  readonly content: string;
}

export interface AssistantMessage {
  readonly role: 'assistant';
  readonly content: string | null;
  readonly toolCalls?: readonly ToolCall[];
  readonly contentBlocks?: readonly ContentBlock[];
  readonly reasoning?: string;
}

export interface ToolMessage {
  readonly role: 'tool';
  readonly toolCallId: string;
  readonly content: string;
}

export type Message = TextMessage | AssistantMessage | ToolMessage;

/** A tool as the model is told about it: OpenAI's function-tool shape. */
export interface ToolSpec {
  readonly type: 'function';
  readonly function: {
    readonly name: string;
    readonly description: string;
    readonly parameters: Readonly<Record<string, unknown>>;
  };
}

export type ToolChoice = 'auto' | 'none' | 'required' | { readonly type: 'function'; readonly function: { readonly name: string } };

/** What the loop asks a transport for. The transport adds whatever its server needs. */
export interface ChatRequest {
  readonly model: string;
  readonly messages: readonly Message[];
  readonly maxTokens: number;
  readonly tools: readonly ToolSpec[];
  readonly toolChoice: ToolChoice;
  readonly signal: AbortSignal;
}

export interface ChatReply {
  /** Null only when the model called tools and wrote nothing. */
  readonly content: string | null;
  readonly toolCalls: readonly ToolCall[];
  /** A thinking Claude turn as written, to send back on the assistant message; empty otherwise. */
  readonly contentBlocks: readonly ContentBlock[];
  /** `stop`, `length`, `tool_calls`, …; `length` means the reply was cut off. Null when not said. */
  readonly finishReason: string | null;
  readonly usage: { readonly promptTokens?: number | null } | null;
}

/** A message with the round it belongs to. The round is never sent; it is how history is cut. */
export interface Held {
  readonly message: Message;
  /** Absent for messages that belong to no round (the system prompt, the person's turn). */
  readonly round?: number;
}
