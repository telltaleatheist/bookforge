import type { Held, Message } from './messages.js';
import type { Transport } from './transport.js';
import { chatWithRetry, DEFAULT_RETRY, type RetryPolicy } from './retry.js';

/**
 * HOW MUCH OF THE CONVERSATION EACH REQUEST CARRIES — chosen per run.
 *
 *   * `trim` (the default): the history is cut in CHUNKS, never round by round,
 *     so the prompt's start stays byte-identical between cuts and prompt caches
 *     keep hitting. What a dropped round did is not lost when the tools hold the
 *     work and the state message says it.
 *   * `full`: every round, every request. When it no longer fits the window the
 *     run fails by name rather than forgetting anything.
 *   * `compact`: every round until the window fills, then the model summarizes
 *     the older rounds into a note that takes their place. For long chats whose
 *     early turns still matter and whose tools hold nothing.
 *
 * Every policy sends `state`, when there is one, as the LAST message. It is
 * never put in the history, so old copies cannot pile up, and it sits after
 * everything that is cached, so it never moves the prefix.
 */
export interface ContextPolicy {
  wire(history: readonly Held[], round: number, state: string | null, signal?: AbortSignal):
    { wired: Message[]; chars: number } | Promise<{ wired: Message[]; chars: number }>;
  /** The request's measured prompt tokens against its characters: the ratio estimates the next. */
  measured(promptTokens: number, chars: number): void;
}

/** The trim policy's two numbers: grow to `high` rounds, then cut back to the latest `low` in one step. */
export const HISTORY_HIGH = 20;
export const HISTORY_LOW = 10;

/** Where dropped rounds were. */
export const DROPPED_NOTE = '[Earlier rounds were removed. The tools hold the work so far.]';

/** The estimate before any request has been measured: a cautious 0.4 tokens a character. */
const FIRST_RATIO = 0.4;

/** A request must leave this much of the window unused: the estimate is an estimate. */
const HEADROOM = 0.95;

export interface SizeOptions {
  /** Tokens, or null when nothing states it: then only chunking applies. */
  readonly window: number | null;
  /** The reply's token budget, which the window must also hold. */
  readonly maxTokens: number;
  /** The tool specs' size in characters, sent with every request. */
  readonly toolChars: number;
}

export interface TrimOptions extends SizeOptions {
  readonly high?: number;
  readonly low?: number;
  readonly droppedNote?: string;
}

function tooBig(window: number | null, chars: number, ratio: number, maxTokens: number): Error {
  return new Error(
    `The conversation no longer fits the model's ${window}-token window, even with only its last round kept `
    + `(about ${Math.round(chars * ratio)} tokens plus ${maxTokens} for the reply). Pick a model with a larger window.`,
  );
}

/**
 * THE HISTORY, FITTED TO THE WINDOW — in chunks.
 *
 * STATEFUL, because a cut is a fact about the run: once old rounds are gone they
 * stay gone, so the next request starts with the same bytes this one did. `cut`
 * is the first round still sent; everything before it is one short note on the
 * person's turn, which changes only at a cut.
 *
 * THE WINDOW IS STILL THE HARD LIMIT. The size is estimated from characters at
 * the ratio the last request measured. When a request does not fit, the history
 * is cut back to `low`, then one round at a time down to the last round, and a
 * request that does not fit even then is refused by name.
 */
export function trimPolicy(options: TrimOptions): ContextPolicy & {
  wire(history: readonly Held[], round: number, state: string | null): { wired: Message[]; chars: number };
} {
  const { window, maxTokens, toolChars } = options;
  const high = options.high ?? HISTORY_HIGH;
  const low = options.low ?? HISTORY_LOW;
  const dropped = options.droppedNote ?? DROPPED_NOTE;
  let tokensPerChar = FIRST_RATIO;
  let cut = 0;
  const fits = (chars: number): boolean => window === null || chars * tokensPerChar + maxTokens <= window * HEADROOM;

  function compose(history: readonly Held[], from: number, state: string | null): Message[] {
    const out: Message[] = [];
    for (const h of history) {
      if (h.round !== undefined && h.round < from) continue;
      const m = h.message;
      if (h.round === undefined && m.role === 'user' && from > 0) {
        // Said on the person's turn, which is where the rounds were.
        out.push({ role: 'user', content: `${m.content}\n\n${dropped}` });
      } else {
        out.push(m);
      }
    }
    if (state !== null) out.push({ role: 'user', content: state });
    return out;
  }
  const size = (ms: readonly Message[]): number => JSON.stringify(ms).length + toolChars;

  return {
    wire(history, round, state) {
      // Rounds 0..round-1 are complete; `round` is the one being asked for.
      if (round - cut > high) cut = round - low;
      for (;;) {
        const wired = compose(history, cut, state);
        const chars = size(wired);
        if (fits(chars)) return { wired, chars };
        if (cut >= round - 1) throw tooBig(window, chars, tokensPerChar, maxTokens);
        cut = round - cut > low ? round - low : cut + 1;
      }
    },
    measured(promptTokens, chars) {
      if (chars > 0) tokensPerChar = promptTokens / chars;
    },
  };
}

/**
 * The trim policy by its old name and signature — `fitter(window, maxTokens,
 * toolChars)` — for code written against the loop before it was a module.
 */
export function fitter(window: number | null, maxTokens: number, toolChars: number): ReturnType<typeof trimPolicy> {
  return trimPolicy({ window, maxTokens, toolChars });
}

/** EVERYTHING, EVERY TIME; a conversation that outgrows the window fails by name. */
export function fullPolicy(options: SizeOptions): ContextPolicy {
  const { window, maxTokens, toolChars } = options;
  let tokensPerChar = FIRST_RATIO;
  return {
    wire(history, _round, state) {
      const wired: Message[] = history.map((h) => h.message);
      if (state !== null) wired.push({ role: 'user', content: state });
      const chars = JSON.stringify(wired).length + toolChars;
      if (window !== null && chars * tokensPerChar + maxTokens > window * HEADROOM) {
        throw new Error(
          `The conversation no longer fits the model's ${window}-token window `
          + `(about ${Math.round(chars * tokensPerChar)} tokens plus ${maxTokens} for the reply), and this run keeps `
          + 'its whole context. Start a new conversation, use the compact or trim policy, or pick a model with a larger window.',
        );
      }
      return { wired, chars };
    },
    measured(promptTokens, chars) {
      if (chars > 0) tokensPerChar = promptTokens / chars;
    },
  };
}

export interface CompactOptions extends SizeOptions {
  /** Who writes the summary: the run's own transport. */
  readonly transport: Transport;
  /** Compact once a request would use this share of the window. Default 0.75. */
  readonly threshold?: number;
  /** The most recent rounds that are never compacted. Default 4. */
  readonly keep?: number;
  /** Tokens for the summary. Default 1500. */
  readonly summaryTokens?: number;
  /** What the model is asked; the rounds follow it. */
  readonly ask?: string;
  readonly retry?: RetryPolicy;
}

export const COMPACT_ASK = 'Below is the earlier part of a conversation in which you worked with tools. Summarize it for yourself so you can carry on without it: what was asked, what you found (with the exact ids, names and values that matter), what you did, what you ruled out, and what is still open. If it begins with an earlier summary, carry forward what still matters from it. Plain text, at most about 400 words.';

/** A round, as text the summary request can carry without needing the tools. */
function transcriptOf(held: readonly Held[], limit = 4000): string {
  const lines: string[] = [];
  for (const { message: m } of held) {
    if (m.role === 'assistant') {
      if (m.content !== null && m.content.trim().length > 0) lines.push(`You said: ${m.content.trim()}`);
      for (const call of m.toolCalls ?? []) lines.push(`You called ${call.function.name}(${call.function.arguments})`);
    } else if (m.role === 'tool') {
      lines.push(`Result: ${m.content.length > limit ? `${m.content.slice(0, limit)}… [cut]` : m.content}`);
    } else {
      lines.push(`${m.role === 'user' ? 'User' : 'System'}: ${m.content}`);
    }
  }
  return lines.join('\n');
}

/**
 * SUMMARIZE, THEN CARRY ON. Rounds before `cut` are replaced by one summary on
 * the person's turn. When a request would pass `threshold` of the window, every
 * round but the last `keep` is summarized (with the summary before it) in one
 * extra request, without tools: the rounds go as a transcript. A request that
 * still does not fit with only the kept rounds is refused by name.
 */
export function compactPolicy(options: CompactOptions): ContextPolicy {
  const { window, maxTokens, toolChars, transport } = options;
  const threshold = options.threshold ?? 0.75;
  const keep = options.keep ?? 4;
  let tokensPerChar = FIRST_RATIO;
  let cut = 0;
  let summary: string | null = null;
  const tokens = (chars: number): number => chars * tokensPerChar + maxTokens;

  function compose(history: readonly Held[], state: string | null): Message[] {
    const out: Message[] = [];
    let carried = false;
    for (const h of history) {
      if (h.round !== undefined && h.round < cut) continue;
      const m = h.message;
      if (!carried && summary !== null && h.round === undefined && m.role === 'user') {
        out.push({ role: 'user', content: `${m.content}\n\n[Summary of the earlier rounds, written by you:]\n${summary}` });
        carried = true;
      } else {
        out.push(m);
      }
    }
    if (state !== null) out.push({ role: 'user', content: state });
    return out;
  }

  return {
    async wire(history, round, state, signal) {
      let wired = compose(history, state);
      let chars = JSON.stringify(wired).length + toolChars;
      if (window === null || tokens(chars) <= window * threshold) return { wired, chars };
      const upTo = round - keep;
      if (upTo > cut) {
        const older = history.filter((h) => h.round !== undefined && h.round >= cut && h.round < upTo);
        const body = `${summary === null ? '' : `Earlier summary:\n${summary}\n\n`}${transcriptOf(older)}`;
        const reply = await chatWithRetry(transport, {
          model: transport.model,
          messages: [{ role: 'user', content: `${options.ask ?? COMPACT_ASK}\n\n${body}` }],
          maxTokens: options.summaryTokens ?? 1500,
          tools: [],
          toolChoice: 'none',
          signal: signal ?? new AbortController().signal,
        }, options.retry ?? DEFAULT_RETRY);
        const written = reply.content?.trim() ?? '';
        if (written.length === 0) {
          throw new Error(`${transport.model} wrote no summary of the earlier rounds, so the conversation cannot be compacted to fit its window.`);
        }
        summary = written;
        cut = upTo;
        wired = compose(history, state);
        chars = JSON.stringify(wired).length + toolChars;
      }
      if (tokens(chars) > window * HEADROOM) throw tooBig(window, chars, tokensPerChar, maxTokens);
      return { wired, chars };
    },
    measured(promptTokens, chars) {
      if (chars > 0) tokensPerChar = promptTokens / chars;
    },
  };
}

/** A policy by name, or the app's own. */
export type ContextChoice = 'trim' | 'full' | 'compact' | ((size: SizeOptions, transport: Transport) => ContextPolicy);

export function policyFor(choice: ContextChoice, size: SizeOptions, transport: Transport, retry: RetryPolicy): ContextPolicy {
  if (typeof choice === 'function') return choice(size, transport);
  switch (choice) {
    case 'trim': return trimPolicy(size);
    case 'full': return fullPolicy(size);
    case 'compact': return compactPolicy({ ...size, transport, retry });
  }
}
