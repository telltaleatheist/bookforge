import type { ChatReply, ChatRequest } from './messages.js';
import type { Transport } from './transport.js';

/**
 * WEATHER IS RETRIED, MISCONFIGURATION IS NAMED. An unreachable server, a 429
 * or a 5xx gets `attempts` tries with a wait that doubles from `firstWaitMs`;
 * any other refusal is the request being wrong and is said in the server's own
 * words at once.
 */
export interface RetryPolicy {
  readonly attempts: number;
  readonly firstWaitMs: number;
  /** Where a retry is said. Default: `console.error` with `[tool-loop]`. */
  readonly log?: (line: string) => void;
}

export const DEFAULT_RETRY: RetryPolicy = { attempts: 4, firstWaitMs: 5_000 };

/** The log line's prefix when the policy names no `log`: `[tool-loop]`, or an app's own word. */
export function logTo(prefix: string): (line: string) => void {
  return (line) => console.error(`[${prefix}] ${line}`);
}

/** One chat, weather retried inside the policy's budget. A cancel is never retried. */
export async function chatWithRetry(
  transport: Transport,
  request: ChatRequest,
  policy: RetryPolicy = DEFAULT_RETRY,
): Promise<ChatReply> {
  const log = policy.log ?? logTo('tool-loop');
  for (let attempt = 1; ; attempt += 1) {
    try {
      return await transport.chat(request);
    } catch (err) {
      if (request.signal.aborted) throw err;
      const said = err instanceof Error ? err.message : String(err);
      if (!transport.isWeather(err)) {
        throw new Error(`${transport.label} refused the request to ${transport.model}: ${said}`);
      }
      if (attempt >= policy.attempts) {
        throw new Error(`${transport.label} did not answer ${transport.model} after ${policy.attempts} tries: ${said}`);
      }
      const wait = policy.firstWaitMs * 2 ** (attempt - 1);
      log(`${transport.label} / ${transport.model}: ${said}; trying again in ${wait / 1000}s`);
      await sleep(wait, request.signal);
    }
  }
}

/** A wait a cancel ends at once, rejecting with the signal's reason. */
export function sleep(ms: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal.aborted) { reject(signal.reason); return; }
    const timer = setTimeout(() => { signal.removeEventListener('abort', stop); resolve(); }, ms);
    const stop = (): void => { clearTimeout(timer); reject(signal.reason); };
    signal.addEventListener('abort', stop, { once: true });
  });
}
