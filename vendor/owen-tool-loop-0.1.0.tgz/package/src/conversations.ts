import { randomUUID } from 'node:crypto';
import { promises as fsp } from 'node:fs';
import * as path from 'node:path';

import type { Message } from './messages.js';
import { sleep } from './retry.js';

/**
 * A CONVERSATION THAT OUTLIVES A RUN. Each turn is one run of the loop. How the
 * next turn starts is the conversation's `carry`:
 *
 *   * `note`: from the working note the model wrote at the end of the last turn
 *     (cheap; the rounds themselves are never carried);
 *   * `full`: from every message of every earlier turn (the whole context, for
 *     as long as the window holds it — pair it with the compact policy).
 */
export interface Conversation {
  readonly id: string;
  readonly title: string;
  readonly createdAt: string;
  readonly updatedAt: string;
  readonly turns: number;
  /** The working note from the last turn, or null when there is none. */
  readonly note: string | null;
  /** Every earlier turn's messages, kept when the conversation carries its full context. */
  readonly messages?: readonly Message[];
  /** Whatever the app keeps beside it. */
  readonly meta?: Readonly<Record<string, unknown>>;
}

/** Where conversations are kept. An app with its own storage implements these four. */
export interface ConversationStore {
  /** Newest first. */
  list(): Promise<Conversation[]>;
  get(id: string): Promise<Conversation | null>;
  put(conversation: Conversation): Promise<void>;
  delete(id: string): Promise<boolean>;
}

const newestFirst = (all: readonly Conversation[]): Conversation[] =>
  [...all].sort((a, b) => (a.updatedAt < b.updatedAt ? 1 : a.updatedAt > b.updatedAt ? -1 : 0));

/** A title from the first request: one line, clipped. */
export function titleOf(request: string, max = 80): string {
  const line = request.replace(/\s+/g, ' ').trim();
  return line.length <= max ? line : `${line.slice(0, max - 1).trimEnd()}…`;
}

/** A new conversation, not yet kept. */
export function newConversation(request: string, at: string = new Date().toISOString()): Conversation {
  return { id: randomUUID(), title: titleOf(request), createdAt: at, updatedAt: at, turns: 0, note: null };
}

export function isConversation(value: unknown): value is Conversation {
  if (typeof value !== 'object' || value === null) return false;
  const c = value as Record<string, unknown>;
  return typeof c['id'] === 'string' && typeof c['title'] === 'string'
    && typeof c['createdAt'] === 'string' && typeof c['updatedAt'] === 'string'
    && typeof c['turns'] === 'number' && Number.isInteger(c['turns']) && (c['turns'] as number) >= 0
    && (c['note'] === null || typeof c['note'] === 'string')
    && (c['messages'] === undefined || Array.isArray(c['messages']))
    && (c['meta'] === undefined || (typeof c['meta'] === 'object' && c['meta'] !== null));
}

/** Kept in memory: for tests, and for a chat that need not outlive the process. */
export class MemoryConversationStore implements ConversationStore {
  readonly #all = new Map<string, Conversation>();

  async list(): Promise<Conversation[]> {
    return newestFirst([...this.#all.values()]);
  }

  async get(id: string): Promise<Conversation | null> {
    return this.#all.get(id) ?? null;
  }

  async put(conversation: Conversation): Promise<void> {
    if (!isConversation(conversation)) throw new Error('That is not a conversation this store can keep.');
    this.#all.set(conversation.id, conversation);
  }

  async delete(id: string): Promise<boolean> {
    return this.#all.delete(id);
  }
}

/**
 * Codes a rename meets on Windows and on a network share when something (an
 * indexer, a virus scanner, the share itself) holds the new file for a moment.
 * Weather: retried inside {@link RENAME_WAITS_MS}.
 */
const RENAME_WEATHER = new Set(['EPERM', 'EBUSY', 'EACCES']);
const RENAME_WAITS_MS = [50, 100, 200, 400, 800, 1600];

/** Write a file whole: a reader finds the old bytes or the new ones, never half of either. */
export async function writeAtomically(file: string, bytes: string | Buffer): Promise<void> {
  await fsp.mkdir(path.dirname(file), { recursive: true });
  const partial = `${file}.${process.pid}.${randomUUID().slice(0, 8)}.partial`;
  await fsp.writeFile(partial, bytes);
  for (let attempt = 0; ; attempt += 1) {
    try {
      await fsp.rename(partial, file);
      return;
    } catch (err) {
      const code = (err as NodeJS.ErrnoException).code ?? '';
      const wait = RENAME_WAITS_MS[attempt];
      if (!RENAME_WEATHER.has(code) || wait === undefined) {
        await fsp.rm(partial, { force: true });
        throw err;
      }
      await sleep(wait, new AbortController().signal);
    }
  }
}

/**
 * One JSON file holding a list of conversations, written whole through
 * {@link writeAtomically}. One writer at a time is the caller's to keep (one
 * process, one run per file); a file that is not this format is refused by
 * name rather than overwritten.
 */
export class JsonFileConversationStore implements ConversationStore {
  readonly #file: string;
  readonly #format: string;

  constructor(file: string, options: { format?: string } = {}) {
    this.#file = file;
    this.#format = options.format ?? 'tool-loop-conversations/v1';
  }

  async #read(): Promise<Conversation[]> {
    let text: string;
    try {
      text = await fsp.readFile(this.#file, 'utf8');
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') return [];
      throw err;
    }
    let value: unknown;
    try {
      value = JSON.parse(text);
    } catch {
      throw new Error(`${this.#file} is not JSON, so its conversations cannot be read.`);
    }
    const body = value as { format?: unknown; conversations?: unknown };
    if (typeof value !== 'object' || value === null || body.format !== this.#format
      || !Array.isArray(body.conversations) || !body.conversations.every(isConversation)) {
      throw new Error(`${this.#file} is not a ${this.#format} list of conversations, so it is not read or overwritten.`);
    }
    return body.conversations as Conversation[];
  }

  async #write(all: readonly Conversation[]): Promise<void> {
    await writeAtomically(this.#file, `${JSON.stringify({ format: this.#format, conversations: newestFirst(all) }, null, 2)}\n`);
  }

  async list(): Promise<Conversation[]> {
    return newestFirst(await this.#read());
  }

  async get(id: string): Promise<Conversation | null> {
    return (await this.#read()).find((c) => c.id === id) ?? null;
  }

  async put(conversation: Conversation): Promise<void> {
    if (!isConversation(conversation)) throw new Error('That is not a conversation this store can keep.');
    const all = await this.#read();
    await this.#write([...all.filter((c) => c.id !== conversation.id), conversation]);
  }

  async delete(id: string): Promise<boolean> {
    const all = await this.#read();
    const kept = all.filter((c) => c.id !== id);
    if (kept.length === all.length) return false;
    await this.#write(kept);
    return true;
  }
}
