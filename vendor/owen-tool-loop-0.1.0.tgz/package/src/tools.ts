import type { ToolSpec } from './messages.js';

/**
 * THE APP SIDE — the tools a model may call. A tool is a name, a sentence the
 * model reads, a JSON schema for its arguments, and a `run`. What it returns is
 * the tool message's text (`content`) and, optionally, a short phrase for the
 * person (`said`: "read ch 12 (e-400–e-460)", "search "Caption" → 14") that the
 * loop hands to progress. `said` is whatever the app wants it to be: a string
 * by default, or a richer object an app words itself.
 */
export interface ToolResult<S = string> {
  readonly content: string;
  readonly said?: S;
}

export interface ToolContext {
  readonly signal: AbortSignal;
  /** The round the call was made in, from 0. */
  readonly round: number;
  /** The call's id, as its tool message names it. */
  readonly callId: string;
}

export interface Tool<S = string> {
  readonly name: string;
  readonly description: string;
  readonly parameters: Readonly<Record<string, unknown>>;
  /** Tools of one group can be added and taken away together. */
  readonly group?: string;
  run(args: Record<string, unknown>, ctx: ToolContext): ToolResult<S> | Promise<ToolResult<S>>;
}

/** A tool, typed. The identity function; it exists so a tool reads as a declaration. */
export function defineTool<S = string>(tool: Tool<S>): Tool<S> {
  return tool;
}

/**
 * WHAT THE LOOP NEEDS FROM THE TOOLS: their specs, and a way to run a call by
 * name with the model's raw JSON. A {@link ToolRegistry} is one; an app with its
 * own dispatcher (one that parses and validates arguments itself) passes that
 * instead and the loop never knows the difference.
 */
export interface ToolSource<S = string> {
  specs(): readonly ToolSpec[];
  call(name: string, args: string, ctx: ToolContext): ToolResult<S> | Promise<ToolResult<S>>;
}

/** What a tool's throw becomes: a result the model reads (the default), or the run's failure. */
export type ToolErrorPolicy = 'result' | 'throw';

/**
 * TOOLS THAT CAN CHANGE WHILE A PROGRAM RUNS. Add one, take one away, or a whole
 * group; the next request tells the model what is there now. A call to a tool
 * that is not there, arguments that are not a JSON object, and a tool that
 * throws are all answered to the model as results by default, so it can correct
 * itself; `onError: 'throw'` makes a throwing tool end the run instead.
 */
export class ToolRegistry<S = string> implements ToolSource<S> {
  readonly #tools = new Map<string, Tool<S>>();
  readonly #onError: ToolErrorPolicy;

  constructor(tools: readonly Tool<S>[] = [], options: { onError?: ToolErrorPolicy } = {}) {
    this.#onError = options.onError ?? 'result';
    for (const tool of tools) this.add(tool);
  }

  add(tool: Tool<S>): this {
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(tool.name)) {
      throw new Error(`"${tool.name}" cannot be a tool's name: letters, digits, _ and - only, at most 64.`);
    }
    if (this.#tools.has(tool.name)) throw new Error(`There is already a tool named "${tool.name}".`);
    this.#tools.set(tool.name, tool);
    return this;
  }

  /** Put a tool in place of the one with its name, or add it. */
  replace(tool: Tool<S>): this {
    this.#tools.delete(tool.name);
    return this.add(tool);
  }

  remove(name: string): boolean {
    return this.#tools.delete(name);
  }

  removeGroup(group: string): number {
    let removed = 0;
    for (const [name, tool] of this.#tools) {
      if (tool.group === group) { this.#tools.delete(name); removed += 1; }
    }
    return removed;
  }

  has(name: string): boolean {
    return this.#tools.has(name);
  }

  names(): string[] {
    return [...this.#tools.keys()];
  }

  specs(): ToolSpec[] {
    return [...this.#tools.values()].map((t) => ({
      type: 'function',
      function: { name: t.name, description: t.description, parameters: t.parameters },
    }));
  }

  async call(name: string, args: string, ctx: ToolContext): Promise<ToolResult<S>> {
    const tool = this.#tools.get(name);
    if (tool === undefined) {
      return { content: `Error: there is no tool named "${name}". The tools are: ${this.names().join(', ')}.` };
    }
    let parsed: unknown;
    try {
      parsed = args.trim().length === 0 ? {} : JSON.parse(args);
    } catch {
      return { content: `Error: the arguments to ${name} are not valid JSON. Send them as one JSON object.` };
    }
    if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
      return { content: `Error: the arguments to ${name} must be one JSON object.` };
    }
    try {
      return await tool.run(parsed as Record<string, unknown>, ctx);
    } catch (err) {
      if (this.#onError === 'throw' || ctx.signal.aborted) throw err;
      return { content: `Error: ${err instanceof Error ? err.message : String(err)}` };
    }
  }
}
