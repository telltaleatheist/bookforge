import { runLoop, type Finished, type LoopOptions } from './loop.js';
import { continuation, takeNote, type NoteOptions } from './note.js';
import { newConversation, type Conversation, type ConversationStore } from './conversations.js';

export interface TurnOptions<S = string> extends Omit<LoopOptions<S>, 'opening' | 'before'> {
  readonly store: ConversationStore;
  /** The conversation to continue, by id; null starts a new one. */
  readonly conversation: string | null;
  readonly request: string;
  /** How the next turn starts: from the model's note (default) or from every earlier message. */
  readonly carry?: 'note' | 'full';
  /**
   * The working note, for `carry: 'note'`: how it is asked for, and how the next
   * turn frames it. False takes no note (the next turn then starts fresh).
   */
  readonly note?: false | (Omit<NoteOptions, 'signal' | 'state'> & { subject?: string; world?: string });
}

export interface Turn {
  readonly finished: Finished;
  readonly conversation: Conversation;
  /** Why the next turn cannot start from a note, or null. The turn's own work stands either way. */
  readonly noteProblem: string | null;
}

/**
 * ONE TURN OF A LONG-TERM CHAT: read the conversation, open from its note or its
 * whole context, run the loop, take the next note, and keep the conversation.
 * Nothing after the loop can fail the turn — the work is done; what is kept is
 * only where the next turn starts — except a cancel.
 */
export async function runTurn<S = string>(options: TurnOptions<S>): Promise<Turn> {
  const carry = options.carry ?? 'note';
  let before: Conversation;
  if (options.conversation === null) {
    before = newConversation(options.request);
  } else {
    const found = await options.store.get(options.conversation);
    if (found === null) {
      throw new Error(`There is no conversation "${options.conversation}" any more (it was deleted), so it cannot be continued. Start a new one.`);
    }
    before = found;
  }
  const noteWords = options.note === false || options.note === undefined ? {} : options.note;
  const opening = carry === 'note' && before.note !== null
    ? continuation(before.note, before.turns, options.request, noteWords)
    : options.request;
  const finished = await runLoop<S>({
    ...options,
    opening,
    ...(carry === 'full' ? { before: before.messages ?? [] } : {}),
  });

  let note: string | null = null;
  let noteProblem: string | null = null;
  if (carry === 'note' && options.note !== false) {
    const noted = await takeNote(options.transport, finished, {
      ...noteWords,
      signal: options.signal,
      state: options.state?.() ?? null,
      ...(options.retry === undefined ? {} : { retry: options.retry }),
    });
    if ('note' in noted) note = noted.note;
    else if ('failed' in noted) noteProblem = `The note for the next turn could not be had (${noted.failed}), so the next turn starts fresh.`;
    else noteProblem = `${options.transport.model} wrote no note for the next turn, so the next turn starts fresh.`;
  }

  const conversation: Conversation = {
    ...before,
    updatedAt: new Date().toISOString(),
    turns: before.turns + 1,
    note,
    ...(carry === 'full' ? { messages: finished.history.slice(1).map((h) => h.message) } : {}),
  };
  try {
    await options.store.put(conversation);
  } catch (err) {
    noteProblem = `The conversation could not be kept (${err instanceof Error ? err.message : String(err)}), so the next turn may not find it.`;
  }
  return { finished, conversation, noteProblem };
}
