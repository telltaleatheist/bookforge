import type { Finished } from './loop.js';
import type { Transport } from './transport.js';
import { chatWithRetry, DEFAULT_RETRY, type RetryPolicy } from './retry.js';

/** Tokens for the note on a local model. A cloud model is given the run's own budget: its thinking is paid from it. */
export const NOTE_MAX_TOKENS = 2000;

/** What the model is asked, after its summary, when the app words nothing of its own. */
export const NOTE_ASK = `The person may ask a follow-up question. Write a working note for yourself to start from then; the person will not see it. Plain text, at most about 300 words:
- what the person has asked so far, every question;
- what you found, with exact ids, names and values;
- what you did with the tools, and why;
- what you searched for or checked and ruled out;
- what is still open or waiting on the person's decision.
If you started from an earlier note, carry forward what still matters from it. Call no tools.`;

export interface NoteOptions {
  readonly signal: AbortSignal;
  /** The work so far, as the loop's state message said it; the ask follows it. Null: the ask alone. */
  readonly state?: string | null;
  readonly ask?: string;
  /** The cap for a local model. Default {@link NOTE_MAX_TOKENS}. */
  readonly maxTokens?: number;
  readonly retry?: RetryPolicy;
}

/** The note, or why there is none — never a throw, except a cancel. */
export type Noted =
  | { readonly note: string }
  | { readonly failed: string }
  | { readonly empty: true };

/**
 * THE WORKING NOTE — one more short request, on the same transport, after the
 * summary: the conversation as the loop left it, with the note asked for in the
 * last message. The tools go with it, because a history holding tool calls is
 * refused without them; any call in the answer is dropped. Weather is retried;
 * what still fails is answered as `failed`, and a cancel still throws.
 */
export async function takeNote(transport: Transport, finished: Finished, options: NoteOptions): Promise<Noted> {
  const ask = options.ask ?? NOTE_ASK;
  const state = options.state ?? null;
  const { wired } = await finished.fit.wire(
    finished.history,
    finished.rounds,
    state === null ? ask : `${state}\n\n${ask}`,
    options.signal,
  );
  let content: string | null;
  try {
    const reply = await chatWithRetry(transport, {
      model: transport.model,
      messages: wired,
      maxTokens: transport.local ? Math.min(finished.maxTokens, options.maxTokens ?? NOTE_MAX_TOKENS) : finished.maxTokens,
      tools: finished.tools,
      toolChoice: 'auto',
      signal: options.signal,
    }, options.retry ?? DEFAULT_RETRY);
    content = reply.content;
  } catch (err) {
    if (options.signal.aborted) throw err;
    return { failed: err instanceof Error ? err.message : String(err) };
  }
  const note = content?.trim() ?? '';
  return note.length === 0 ? { empty: true } : { note };
}

/**
 * THE FIRST MESSAGE OF A FOLLOW-UP — the note framed as leads to check, then the
 * person's words. `subject` names what the conversation is about ("this book",
 * "this project"); `world` says what may have changed since.
 */
export function continuation(
  note: string,
  turns: number,
  request: string,
  words: { subject?: string; world?: string } = {},
): string {
  const subject = words.subject ?? 'this work';
  const world = words.world ?? 'since then things may have changed, and your tools read them as they stand now.';
  return `This question continues an earlier conversation about ${subject}. Below is the working note you wrote for yourself at the end of it. Treat it as leads to check, not facts: ${world} Confirm with your tools before you act on anything in it; you need not survey again what it already tells you.

Your note, after ${turns} ${turns === 1 ? 'question' : 'questions'}:
<note>
${note}
</note>

The person now says:
${request}`;
}
